public class Cell {
    SnakeLadder snakeLadder;

    public SnakeLadder getSnakeLadder() {
        return snakeLadder;
    }
}
